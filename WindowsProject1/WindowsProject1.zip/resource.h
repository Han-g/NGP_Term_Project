﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// WindowsProject1.rc에서 사용되고 있습니다.
//
#define IDC_MYICON                      2
#define IDD_WINDOWSPROJECT1_DIALOG      102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINDOWSPROJECT1             107
#define IDI_SMALL                       108
#define IDC_WINDOWSPROJECT1             109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     131
#define IDB_BITMAP3                     132
#define IDB_BITMAP4                     133
#define IDB_BITMAP5                     134
#define IDB_BITMAP6                     135
#define IDB_BITMAP7                     136
#define IDB_BITMAP8                     137
#define IDB_BITMAP9                     138
#define IDB_BITMAP10                    139
#define IDB_BITMAP11                    140
#define IDB_BITMAP12                    141
#define IDB_BITMAP13                    142
#define IDB_BITMAP14                    143
#define IDB_BITMAP15                    144
#define IDB_BITMAP16                    145
#define IDB_BITMAP17                    146
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
